package net.onest.qa.service.impl;

import java.util.List;

import net.onest.qa.dao.StatusDao;
import net.onest.qa.dao.impl.StatusDaoImpl;
import net.onest.qa.entity.Client;
import net.onest.qa.service.StatusService;

public class StatusServiceImpl implements StatusService{
	private static StatusServiceImpl ssi = new StatusServiceImpl();
	private StatusServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	public static StatusServiceImpl getInstance() {
		return ssi;
	}

	@Override
	public Boolean addClient(int clientId) {
		StatusDao sd = StatusDaoImpl.getInstance();
		Boolean result = sd.addClient(clientId);
		return result;
	}

	@Override
	public String findClientStatus(int clientId) {
		StatusDao sd = StatusDaoImpl.getInstance();
		String status = sd.findClientStatus(clientId);
		return status;
	}

	@Override
	public Boolean updateClientStatus(int clientId, String status) {
		StatusDao sd = StatusDaoImpl.getInstance();
		Boolean result = sd.updateClientStatus(clientId, status);
		return result;
	}
	@Override
	public Boolean isHaveStatus(int clientId) {
		StatusDao sd = StatusDaoImpl.getInstance();
		Boolean result = sd.isHaveStatus(clientId);
		return result;
	}
	@Override
	public List<Client> findonLineClient(List<Client> clients) {
		StatusDao sd = StatusDaoImpl.getInstance();
		return sd.findonLineClient(clients);
	}

}
