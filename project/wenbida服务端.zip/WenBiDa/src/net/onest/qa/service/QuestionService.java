package net.onest.qa.service;

import java.util.List;

import net.onest.qa.entity.Question;



public interface QuestionService {
	public List<Question> getAnswerList(int clientId);
	public Question getQuestionDetail(int questionid);
	public int addQuestion(Question question);
	public boolean deleteQuestion(int questionid);
	public boolean updateQuestion(Question question,int questionid);
	public List<Question> getAllQuestions();
	public List<Question> getQuestionsByLevel(String questionlevel);
	public List<Question> getQuestionsByLevelAndDirection(String questionlevel,String questiondirection);
	public List<Question> getQuestionsByOrder();
	List<Question> getQuestionByClientId(int clientId);
	public List<Question> getAllQuestions(int pagenum,int pagesize);
	List<Question> getFilterData(String sql);
}
