package net.onest.qa.service.impl;

import java.util.List;

import net.onest.qa.dao.ClientDao;
import net.onest.qa.dao.impl.ClientDaoImpl;
import net.onest.qa.entity.Client;
import net.onest.qa.service.ClientService;
import net.onest.qa.service.impl.ClientServiceImpl;



public class ClientServiceImpl implements ClientService {

	private ClientServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	private static ClientServiceImpl csi = new ClientServiceImpl();
	public static ClientServiceImpl getInstance() {
		return csi;
	}
	
	//�ж��û��Ƿ�ע��ɹ�
	@Override
	public Boolean isAddUser(Client client) {
		ClientDao cd = ClientDaoImpl.getInstance();
		return cd.isAddUser(client);
	}

	//�ж��Ƿ�����û�
	@Override
	public Boolean isExistUser(Client client) {
		ClientDao cd = ClientDaoImpl.getInstance();
		return cd.isExistUser(client);
	}

	//�ж��û���Ϣ�Ƿ��޸ĳɹ�
	@Override
	public Boolean isUpdateInfo(Client client) {
		ClientDao cd = ClientDaoImpl.getInstance();
		return cd.isUpdateInfo(client);
	}

	//�ж��û�����Ƿ��޸ĳɹ�
	@Override
	public Boolean isUpdateBalance(int id,int balance) {
		ClientDao cd = ClientDaoImpl.getInstance();
		return cd.isUpdateBalance(id, balance);
	}

	//�ж��û��������Ƿ��޸ĳɹ�
	@Override
	public Boolean isUpdateQuestionNum(int id) {
		ClientDao cd = ClientDaoImpl.getInstance();
		return cd.isUpdateQuestionNum(id);
	}

	/**
	 * ���»ش���
	 * @param id �û�id
	 * @return boolean true/false
	 */
	@Override
	public Boolean isUpdateAnswerNum(int id) {
		ClientDao cd = ClientDaoImpl.getInstance();
		return cd.isUpdateAnswerNum(id);
	}

	/**
	 * ���º�����
	 * @param �û�id
	 * @return boolean true/false
	 */
	@Override
	public Boolean isUpdateOpinionNum(int id) {
		ClientDao cd = ClientDaoImpl.getInstance();
		return cd.isUpdateOpinionNum(id);
	}
	
	/**
	 * ����id��ѯ�û���Ϣ
	 * @param id �û�id
	 * @return client �û�����
	 */
	@Override
	public Client findClientInfo(int id) {
		ClientDao cd = ClientDaoImpl.getInstance();
		Client client = cd.findClientInfo(id);
		return client;
	}
	
	/**
	 * ��ȡ���������б�
	 * @param client �����û�
	 * @return ���������б�
	 */
	@Override
	public List<Client> findExcellentClient(List<Client> clients) {
		ClientDao cd = ClientDaoImpl.getInstance();
		List<Client> excellentClients = cd.findExcellentClient(clients);
		return excellentClients;
	}
	/**
	 * ��ȡ�����û�����
	 */
	@Override
	public List<Client> findAllClient(String subject) {
		ClientDao cd = ClientDaoImpl.getInstance();
		List<Client> clients = cd.findAllClient(subject);
		return clients;
	}
	
	@Override
	public int getClientId(Client client) {
		int clientId=0;
		ClientDao cd = ClientDaoImpl.getInstance();
		clientId = cd.getClientId(client);
		return clientId;
	}


	

}
