package net.onest.qa.service.impl;

import java.util.ArrayList;
import java.util.List;

import net.onest.qa.dao.SubscribeDao;
import net.onest.qa.dao.impl.SubscribeDaoImpl;
import net.onest.qa.entity.Subscribe;
import net.onest.qa.service.SubscribeService;

public class SubscribeServiceImpl implements SubscribeService{
	private static SubscribeServiceImpl ssi = new SubscribeServiceImpl();
	private SubscribeServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	public static SubscribeServiceImpl getInstance() {
		return ssi;
	}

	@Override
	public Boolean addSubscribe(int subscribeId, int questionId, int publisherId) {
		SubscribeDao subscribeDao = SubscribeDaoImpl.getInstance();
		Boolean result = subscribeDao.addSubscribe(subscribeId, questionId, publisherId);
		
		return result;
	}

	@Override
	public Boolean deleteSubscribe(int questionId) {
		SubscribeDao subscribeDao = SubscribeDaoImpl.getInstance();
		Boolean result = subscribeDao.deleteSubscribe(questionId);
		return result;
	}

	@Override
	public Boolean updateStatus(int questionId) {
		SubscribeDao subscribeDao = SubscribeDaoImpl.getInstance();
		Boolean result = subscribeDao.updateStatus(questionId);
		return result;
	}

	@Override
	public List<Subscribe> getMySubscribe(int publisherId) {
		List<Subscribe> mySubscribeList = new ArrayList<>();
		SubscribeDao subscribeDao = SubscribeDaoImpl.getInstance();
		mySubscribeList = subscribeDao.getMySubscribe(publisherId);
		return mySubscribeList;
	}

	@Override
	public List<Subscribe> getSubscribeMe(int subscribedId) {
		List<Subscribe> subscribedList = new ArrayList<>();
		SubscribeDao subscribeDao = SubscribeDaoImpl.getInstance();
		subscribedList = subscribeDao.getSubscribeMe(subscribedId);
		return subscribedList;
	}

}
