package net.onest.qa.service;

import java.util.List;

import net.onest.qa.entity.Client;

public interface StatusService {
	Boolean addClient(int clientId);
	String findClientStatus(int clientId);
	Boolean updateClientStatus(int clientId,String status);
	Boolean isHaveStatus(int clientId);
	List<Client> findonLineClient(List<Client> clients);
}
