package net.onest.qa.service;

import java.util.List;

import net.onest.qa.entity.Subscribe;

public interface SubscribeService {
	//����ԤԼ
		Boolean addSubscribe(int subscribeId,int questionId,int publisherId);
		//ɾ��ԤԼ
		Boolean deleteSubscribe(int questionId);
		//�޸�����״̬
		Boolean updateStatus(int questionId);
		//�ҵ�ԤԼ
		List<Subscribe> getMySubscribe(int publisherId);
		//ԤԼ�ҵ�
		List<Subscribe> getSubscribeMe(int subscribedId);

}
