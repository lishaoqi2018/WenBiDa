package net.onest.qa.service.impl;

import java.util.ArrayList;
import java.util.List;

import net.onest.qa.dao.QuestionDao;
import net.onest.qa.dao.impl.QuestionDaoImpl;
import net.onest.qa.entity.Question;
import net.onest.qa.service.QuestionService;



public class QuestionServiceImpl implements QuestionService{
	private static QuestionServiceImpl qsi = new QuestionServiceImpl();
	private QuestionServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	public static QuestionServiceImpl getInstance() {
		return qsi;
	}

	@Override
	public Question getQuestionDetail(int questionid) {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		Question question = questiondao.getQuestionDetail(questionid);
		return question;
	}

	@Override
	public int addQuestion(Question question) {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		int i = questiondao.addQuestion(question);
		return i;
	}

	@Override
	public boolean deleteQuestion(int questionid) {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		boolean b = questiondao.deleteQuestion(questionid);
		return b;
	}

	@Override
	public boolean updateQuestion(Question question, int questionid) {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		boolean b = questiondao.updateQuestion(question,questionid);
		return b;
	}

	@Override
	public List<Question> getAllQuestions() {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		List<Question> questions = new ArrayList<>();
		questions = questiondao.getAllQuestions();
		return questions;
	}

	@Override
	public List<Question> getQuestionsByLevel(String questionlevel) {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		List<Question> questions = new ArrayList<>();
		questions = questiondao.getQuestionsByLevel(questionlevel);
		return questions;
	}

	@Override
	public List<Question> getQuestionsByLevelAndDirection(String questionlevel, String questiondirection) {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		List<Question> questions = new ArrayList<>();
		questions = questiondao.getQuestionsByLevelAndDirection(questionlevel,questiondirection);
		return questions;
	}

	@Override
	public List<Question> getQuestionsByOrder() {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		List<Question> questions = new ArrayList<>();
		questions = questiondao.getQuestionsByOrder();
		return questions;
	}
	@Override
	public List<Question> getQuestionByClientId(int clientId) {
		QuestionDao questionDao = QuestionDaoImpl.getInstance();
		List<Question> questionList = new ArrayList<>();
		questionList = questionDao.getQuestionByClientId(clientId);
		return questionList;
	}
	@Override
	public List<Question> getAllQuestions(int pagenum, int pagesize) {
		QuestionDao questiondao = QuestionDaoImpl.getInstance();
		List<Question> questions = new ArrayList<>();
		questions = questiondao.getAllQuestions(pagenum,pagesize);
		return questions;
	}
	@Override
	public List<Question> getAnswerList(int clientId) {
		QuestionDao qd = QuestionDaoImpl.getInstance();
		List<Question> answers = qd.getAnswerList(clientId);
		return answers;
	}
	@Override
	public List<Question> getFilterData(String sql) {
		List<Question> questionList = new ArrayList<>();
		QuestionDao qd = QuestionDaoImpl.getInstance();
		questionList = qd.getFilterData(sql);
		return questionList;
	}

	
}

