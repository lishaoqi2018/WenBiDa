package net.onest.qa.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import net.onest.qa.dao.SubscribeDao;
import net.onest.qa.entity.Subscribe;
import net.onest.qa.util.DBUtil;

public class SubscribeDaoImpl implements SubscribeDao{
	private static SubscribeDaoImpl sdi = new SubscribeDaoImpl();
	private SubscribeDaoImpl() {
		// TODO Auto-generated constructor stub
	}
	public static SubscribeDaoImpl getInstance() {
		return sdi;
	}
	

	/*  int subscribeId   ԤԼid
	 * 	int questionId    ����id
	 * 	int	publisherId   ������id
	 * 
	 * ����ԤԼ
	 * 
	 * @see net.onest.lhx.dao.SubscribeDao#addSubscribe(int, int, int)
	 */
	@Override
	public Boolean addSubscribe(int subscribeId, int questionId, int publisherId) {
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps =null;
		String sql = "";
		sql = "insert into subscribe (subscribed_id,question_id,publisher_id,question_status) "
				+ "values('"+subscribeId+"','"+questionId+"','"+publisherId+"','δ���');";
		int result = 0;
		try {
			ps =conn.prepareStatement(sql);
			result = ps.executeUpdate();
			if(result>0) {
				return true;
			}else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.close(ps, conn);
		
				
		return false;
		
	}

	/* int questionId  ����id
	 * 
	 * ���ԤԼ
	 * 
	 * @see net.onest.lhx.dao.SubscribeDao#deleteSubscribe(int)
	 */
	@Override
	public Boolean deleteSubscribe(int questionId) {
		Connection conn =DBUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "";
		try {
				sql = "delete from subscribe where question_id ='"+questionId+"';";
				ps = conn.prepareStatement(sql);
				int result =ps.executeUpdate();
				//���ݽ���жϷ���ֵ
				if(result > 0) {
					return true;
				}else {
					return false;
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		DBUtil.close(ps, conn);
		return false;
	}

	/* int questionId  ����id
	 * 
	 * �޸�����״̬
	 * 
	 * @see net.onest.lhx.dao.SubscribeDao#updateStatus(int)
	 */
	@Override
	public Boolean updateStatus(int questionId) {
		Connection conn  = DBUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "";
		String status ="�ѽ��";
		try {
				sql = "update subscribe set question_status='"+status+"'where question_id ='"+questionId+"';";
				ps = conn.prepareStatement(sql);
				int result =ps.executeUpdate();
				//���ݽ���жϷ���ֵ
				if(result > 0) {
					return true;
				}else {
					return false;
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		DBUtil.close(ps, conn);
		return false;
	}

	/* int publisherId  ������id
	 * 
	 * ��ȡ�ҵ�ԤԼ
	 * 
	 * @see net.onest.lhx.dao.SubscribeDao#getMySubscribe(int)
	 */
	@Override
	public List<Subscribe> getMySubscribe(int publisherId) {
		List<Subscribe> mySubscribeList = new ArrayList<>();
		String sql ="";
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;		
		try {
			sql="select * from subscribe where publisher_id = '"+publisherId+"' and question_status = 'δ���';";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				Subscribe subscribe = new Subscribe();
				subscribe.setSubscribeId(rs.getInt("subscribe_id"));
				subscribe.setPublisherId(rs.getInt("publisher_id"));
				subscribe.setQuestionId(rs.getInt("question_id"));
				subscribe.setSubscribedId(rs.getInt("subscribed_id"));
				subscribe.setQuestionStatus(rs.getString("question_status"));
				mySubscribeList.add(subscribe);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.close(rs, ps, conn);
		return mySubscribeList;
	}

	/*int subscribedId ��ԤԼ��id
	 * 
	 * ��ȡԤԼ�ҵ�
	 * 
	 * @see net.onest.lhx.dao.SubscribeDao#getSubscribeMe(int)
	 */
	@Override
	public List<Subscribe> getSubscribeMe(int subscribedId) {
		List<Subscribe> subscribedList = new ArrayList<>();
		String sql ="";
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			sql = "select * from subscribe where subscribed_id= ? and question_status = 'δ���'";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, subscribedId);
			rs = ps.executeQuery();
			while(rs.next()) {
				Subscribe subscribe = new Subscribe();
				subscribe.setSubscribeId(rs.getInt("subscribe_id"));
				subscribe.setPublisherId(rs.getInt("publisher_id"));
				subscribe.setQuestionId(rs.getInt("question_id"));
				subscribe.setSubscribedId(rs.getInt("subscribed_id"));
				subscribe.setQuestionStatus(rs.getString("question_status"));
				subscribedList.add(subscribe);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.close(rs, ps, conn);
		return subscribedList;
	}

	
}
