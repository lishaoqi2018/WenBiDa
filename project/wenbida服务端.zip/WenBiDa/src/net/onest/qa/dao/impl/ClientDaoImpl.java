package net.onest.qa.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import net.onest.qa.dao.ClientDao;
import net.onest.qa.entity.Client;
import net.onest.qa.util.DBUtil;

public class ClientDaoImpl implements ClientDao{
	
	//����ģʽ
	private static ClientDaoImpl cdi = new ClientDaoImpl();
	private ClientDaoImpl() {
		// TODO Auto-generated constructor stub
	}
	public static ClientDaoImpl getInstance() {
		return cdi;
	}
	
	
	@Override
	//�ж��û��Ƿ�ע��ɹ�
	public Boolean isAddUser(Client client) {
		Connection conn = DBUtil.getConnection();
		String phone = client.getClientPhone();
		String pwd = client.getPassword();
		String sql = "insert into client(client_phone,password) values ('"+phone+"','"+pwd+"')";
		PreparedStatement ps = null;
		int lines = 0;
		try {
			ps = conn.prepareStatement(sql);
			lines = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(null, ps, conn);
		}
		if(lines>0) {
			return true;
		}else {
			return false;
		}
	}
	@Override
	//�ж��Ƿ�����û�
	public Boolean isExistUser(Client client) {
		Connection conn = DBUtil.getConnection();
		String phone = client.getClientPhone();
		String pwd = client.getPassword();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select * from client where client_phone='"+phone+"' and password='"+pwd+"'";
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(rs, ps, conn);
		}
		return false;
	}

	//�ж��û���Ϣ�Ƿ��޸ĳɹ�
	@Override
	public Boolean isUpdateInfo(Client client) {
		int id = client.getClientId();         
		String name = client.getClientName();    
		String gender = client.getClientGender();  
		String idCard = client.getClientIdCard();  
		String realName = client.getClientRealName();
		String education = client.getClientEducation();
		String realm = client.getClientRealm();    
		int minMoney = client.getClientMinMoney();  
		String photo = client.getClientPhoto();
		Connection conn = DBUtil.getConnection();
		String sql = "update client set client_name = '"+name+"' , client_gender='"+gender+"' , "
				+ "client_id_card = '"+idCard+"' , client_real_name = '"+realName+"' , "
				+ "client_education = '"+education+"' , client_realm = '"+realm+"' , "
				+ "client_min_money = "+minMoney+" , client_photo = '"+photo+"' where client_id="+id+" ";
		PreparedStatement ps = null;
		int lines = 0;
		try {
			ps = conn.prepareStatement(sql);
			lines = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(null, ps, conn);
		}
		if(lines>0) {
			return true;
		}else {
			return false;
		}
	}

	//�ж��û�����Ƿ��޸ĳɹ�
	@Override
	public Boolean isUpdateBalance(int id,int balance) {
		Connection conn = DBUtil.getConnection();
		String sql = "update client set client_banlance = "+balance+" where client_id = "+id+"";
		PreparedStatement ps = null;
		int lines = 0;
		try {
			ps = conn.prepareStatement(sql);
			lines = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(null, ps, conn);
		}
		if(lines>0) {
			return true;
		}else {
			return false;
		}
	}

	//�ж��û��������Ƿ��޸ĳɹ�
	@Override
	public Boolean isUpdateQuestionNum(int id) {
		Connection cn = DBUtil.getConnection();
		String sql = "update client set question_num = question_num + 1"
				+ " where client_id = "+id+"";
		int i = 0;
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			i = ps.executeUpdate();
			//�ر�����
			DBUtil.close(null,ps, cn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i > 0 ? true : false;
	}

	/**
	 * ���»ش���
	 * @param id �û�id
	 * @return boolean true/false
	 */
	@Override
	public Boolean isUpdateAnswerNum(int id) {
		Connection cn = DBUtil.getConnection();
		String sql = "update client set answer_num = answer_num + 1"
				+ " where client_id = "+id+"";
		int i = 0;
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			i = ps.executeUpdate();
			//�ر�����
			DBUtil.close(null,ps, cn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i > 0 ? true : false;
	}

	/**
	 * ���º�����
	 * @param �û�id
	 * @return boolean true/false
	 */
	@Override
	public Boolean isUpdateOpinionNum(int id) {
		Connection cn = DBUtil.getConnection();
		String sql = "update client set high_opinion_num = high_opinion_num + 1"
				+ " where client_id = "+id+"";
		int i = 0;
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			i = ps.executeUpdate();
			//�ر�����
			DBUtil.close(null,ps, cn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i > 0 ? true : false;
	}

	/**
	 * ����id��ѯ�û���Ϣ
	 * @param id �û�id
	 * @return client �û�����
	 */
	@Override
	public Client findClientInfo(int id) {

		Client client = new Client();
		Connection cn = DBUtil.getConnection();
		String sql = "select * from client where client_id = "+id+"";
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				client.setClientId(rs.getInt(1));
				client.setClientPhone(rs.getString(2));
				client.setPassword(rs.getString(3));
				client.setClientName(rs.getString(4));
				client.setClientGender(rs.getString(5));
				client.setClientIdCard(rs.getString(6));
				client.setClientRealName(rs.getString(7));
				client.setClientEducation(rs.getString(8));
				client.setClientRealm(rs.getString(9));
				client.setClientMinMoney(rs.getInt(10));
				client.setClientBalance(rs.getInt(11));
				client.setClientPhoto(rs.getString(12));
				client.setQuestionNum(rs.getInt(13));
				client.setAnswerNum(rs.getInt(14));
				client.setHighOpinionNum(rs.getInt(15));
			}
			//�ر�����
			DBUtil.close(rs, ps, cn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return client;
	}

	/**
	 * ��ȡ���������б�
	 * @param client �����û�
	 * @return ���������б�
	 */
	@Override
	public List<Client> findExcellentClient(List<Client> clients) {
		//����������б�
		List<Client> excellentClients = new ArrayList<Client>();

		for(Client client:clients) {
			if(client.getAnswerNum()>15) {
				int anum = client.getAnswerNum();
				int onum = client.getHighOpinionNum();
				if((float)onum/anum > 0.9) {
					excellentClients.add(client);
				}
			}
		}
		return excellentClients;
	}
	
	/**
	 * ��ȡ�����û�����
	 */
	@Override
	public List<Client> findAllClient(String subject) {
		List<Client> clients = new ArrayList<Client>();
		Connection cn = DBUtil.getConnection();
		StringBuilder sql = new StringBuilder("select * from client where 1=1 ");
		try {
			if (!"".equals(subject)) {
				sql.append(" and client_realm ='"+subject+"' ");
			}
			PreparedStatement ps = cn.prepareStatement(sql.toString());
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Client client = new Client();
				client.setClientId(rs.getInt(1));
				client.setClientPhone(rs.getString(2));
				client.setPassword(rs.getString(3));
				client.setClientName(rs.getString(4));
				client.setClientGender(rs.getString(5));
				client.setClientIdCard(rs.getString(6));
				client.setClientRealName(rs.getString(7));
				client.setClientEducation(rs.getString(8));
				client.setClientRealm(rs.getString(9));
				client.setClientMinMoney(rs.getInt(10));
				client.setClientBalance(rs.getInt(11));
				client.setClientPhoto(rs.getString(12));
				client.setQuestionNum(rs.getInt(13));
				client.setAnswerNum(rs.getInt(14));
				client.setHighOpinionNum(rs.getInt(15));
				clients.add(client);
			}
			//�ر�����
			DBUtil.close(rs, ps, cn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clients;
	}
	
	@Override
	public int getClientId(Client client) {
		int  clientId = 0;
		String clientPhone = client.getClientPhone();
		String sql = "";
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			sql = "select client_id from client where client_phone ='"+clientPhone+"';";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				clientId = rs.getInt(1);
			}
		DBUtil.close(rs, ps, conn);	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return clientId;
	}
	
}
