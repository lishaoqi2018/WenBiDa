package net.onest.qa.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import net.onest.qa.dao.StatusDao;
import net.onest.qa.entity.Client;
import net.onest.qa.util.DBUtil;

public class StatusDaoImpl implements StatusDao{
	private static StatusDaoImpl sdi = new StatusDaoImpl();
	private StatusDaoImpl() {};
	public static StatusDaoImpl getInstance() {
		return sdi;
	}

	@Override
	public String findClientStatus(int clientId) {
		String status="";
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps =null;
		ResultSet rs = null;
		String sql ="";
		try {
			sql="select status from cstatus where client_id = '"+clientId+"';";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				status = rs.getString(1);
			}
			DBUtil.close(rs, ps, conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}

	@Override
	public Boolean updateClientStatus(int clientId,String status) {
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		String sql ="";
		int result =0;
		try {
			sql="update cstatus set status ='"+status+"'where client_id='"+clientId+"';";
			ps = conn.prepareStatement(sql);
			result = ps.executeUpdate();
			if(result>0) {
				return true;
			}else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.close(ps, conn);
		return false;
	}

	@Override
	public Boolean addClient(int clientId) {
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "";
		int result =0;
		try {
			sql="insert into cstatus (client_id) values('"+clientId+"');";
			ps = conn.prepareStatement(sql);
			result = ps.executeUpdate();
			if(result>0) {
				return true;
			}else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.close(ps, conn);
		return false;
	}
	@Override
	public Boolean isHaveStatus(int clientId) {
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		ResultSet rs  = null;
		String sql = "";
		try {
			sql = "select * from cstatus where client_id ='"+clientId+"';";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBUtil.close(rs, ps, conn);
		return false;
	}

	@Override
	public List<Client> findonLineClient(List<Client> clients) {
		List<Client> onlineClients = new ArrayList<Client>();
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		ResultSet rs  = null;
		
		for(Client client:clients) {
			int clientId = client.getClientId();
			String sql = "select * from cstatus where client_id ='"+clientId+"'and status='on' ;";
			try {
				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				while(rs.next()) {
					onlineClients.add(client);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		DBUtil.close(rs, ps, conn);
		return onlineClients;
	}
}
