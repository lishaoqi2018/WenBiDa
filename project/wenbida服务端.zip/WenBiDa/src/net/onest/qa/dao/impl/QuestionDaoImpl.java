package net.onest.qa.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import net.onest.qa.dao.QuestionDao;
import net.onest.qa.entity.Question;
import net.onest.qa.util.DBUtil;



public class QuestionDaoImpl implements QuestionDao{
	
	private static QuestionDaoImpl qdi = new QuestionDaoImpl();
	private QuestionDaoImpl() {
		
	}
	public static QuestionDaoImpl getInstance() {
		return qdi;
	}
	
	/**
	 *��ȡ����ϸ��,����һ���������
	 */
	@Override
	public Question getQuestionDetail(int questionid) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		//1.��ȡ���ݿ�����
		Connection c = DBUtil.getConnection();
		PreparedStatement ps;
		ResultSet rs = null;
		Question question= new Question();
		//2.���в�ѯ
		String sql = "select*from question where question_id = ?";
		try {
			ps= c.prepareStatement(sql);
			ps.setInt(1, questionid);
			rs= ps.executeQuery();
			while(rs.next()) {
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));	
				question.setAnswerId(rs.getInt(12));
			}
			DBUtil.close(rs, ps, c);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		//3.����
		return question;
	}
	//����һ�����⣬�ͻ��˴���һ���������
	@Override
	public int addQuestion(Question question) {
		// TODO Auto-generated method stub
		int id = -1;
		int n = -1;
		Connection c = DBUtil.getConnection();
		PreparedStatement ps;
		String sql = "insert into question(question_title,question_content,question_photo,publisher_id,publisher_online_time,question_level,question_direction,question_money,question_status,publish_time,answer_id) values(?,?,?,?,?,?,?,?,?,?,?)";
		try {
			ps= c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, question.getQuestionTitle());
			ps.setString(2, question.getQuestionContent());
			ps.setString(3, question.getQuestionPhoto());
			ps.setInt(4, question.getPublisherId());
			ps.setString(5, question.getPublisherOnlineTime());
			ps.setString(6, question.getQuestionLevel());
			ps.setString(7, question.getQuestionDirection());
			ps.setInt(8, question.getQuestionMoney());
			ps.setString(9, question.getQuestionStatus());
			ps.setString(10, question.getPublishTime());
			ps.setInt(11, question.getAnswerId());	
			n= ps.executeUpdate();
			if(n>0) {
				ResultSet rs = ps.getGeneratedKeys();
				if(rs.next()) {
					id = rs.getInt(1);
				}
				DBUtil.close(rs, ps, c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}
	//��������idɾ������,������boolean�ж��Ƿ�ɾ���ɹ�
	@Override
	public boolean deleteQuestion(int questionid) {
		Connection cn = DBUtil.getConnection();
		String sql = "delete from question where question_id = ?";
		PreparedStatement ps;
		int n=-1;
		try {
			ps = cn.prepareStatement(sql);
			ps.setInt(1, questionid);
			n= ps.executeUpdate();
			cn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		if(n>0) {
			return true;
		}else {
			return false;
		}
	}
	//��������id�������⣬������boolean�ж��Ƿ���³ɹ�
	@Override
	public boolean updateQuestion(Question question,int questionid) {
		Connection cn = DBUtil.getConnection();
		String sql = "update question set question_title=?,question_content=?,question_photo=?,publisher_id=?,publisher_online_time=?,question_level=?,question_direction=?,question_money=?,question_status=?,publish_time=?,answer_id=? where question_id=?";
		PreparedStatement ps;
		int n =-1;
		try {
			ps = cn.prepareStatement(sql);
			ps.setString(1, question.getQuestionTitle());
			ps.setString(2, question.getQuestionContent());
			ps.setString(3, question.getQuestionPhoto());
			ps.setInt(4, question.getPublisherId());
			ps.setString(5, question.getPublisherOnlineTime());
			ps.setString(6, question.getQuestionLevel());
			ps.setString(7, question.getQuestionDirection());
			ps.setInt(8, question.getQuestionMoney());
			ps.setString(9, question.getQuestionStatus());
			ps.setString(10, question.getPublishTime());
			ps.setInt(11, question.getAnswerId());	
			ps.setInt(12, questionid);
			n = ps.executeUpdate();
			cn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		if(n>0) {
			return true;
		}else {
			return false;
		}
	}
	//��ȡ�������⣬������𣬷������������б�
	@Override
	public List<Question> getAllQuestions() {
		List<Question> questionList = new ArrayList<>();
		Connection cn = DBUtil.getConnection();
		String sql = "select * from question";
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Question question = new Question();
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));	
				question.setAnswerId(rs.getInt(12));
				questionList.add(question);
			}
			cn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return questionList;
	}
	//����Ϊ���⼶�𣬷��������б�
	@Override
	public List<Question> getQuestionsByLevel(String questionlevel) {
		List<Question> questionList = new ArrayList<>();
		Connection cn = DBUtil.getConnection();
		String sql = "select * from question where question_level=?";
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			ps.setString(1, questionlevel);
			while (rs.next()) {
				Question question = new Question();
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));	
				question.setAnswerId(rs.getInt(12));
				questionList.add(question);
			}
			cn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return questionList;
	}
	//����Ϊ�������ͷ��򣬷���ֵΪ�����б�
	@Override
	public List<Question> getQuestionsByLevelAndDirection(String questionlevel, String questiondirection) {
		List<Question> questionList = new ArrayList<>();
		Connection cn = DBUtil.getConnection();
		String sql = "select * from question where question_level=? and question_direction=?";
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			ps.setString(1, questionlevel);
			ps.setString(2, questiondirection);
			while (rs.next()) {
				Question question = new Question();
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));	
				question.setAnswerId(rs.getInt(12));
				questionList.add(question);
			}
			cn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return questionList;
	}
	//���ճ��Ӵ�С��С�������򣬷��������б�
	@Override
	public List<Question> getQuestionsByOrder() {
		List<Question> questionList = new ArrayList<>();
		Connection cn = DBUtil.getConnection();
		String sql = "select * from question order by question_money desc";
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Question question = new Question();
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));	
				question.setAnswerId(rs.getInt(12));
				questionList.add(question);
			}
			cn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return questionList;
	}
	@Override
	public List<Question> getQuestionByClientId(int clientId) {
		List<Question> questionList = new ArrayList<>();
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps =null;
		ResultSet rs = null;
		String sql = "";
		try {
			sql = "select * from question where publisher_id ='"+clientId+"';";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				Question question = new Question();
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));
				question.setAnswerId(rs.getInt(12));
				questionList.add(question);
			}
			DBUtil.close(rs, ps, conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return questionList;
	}
	
	@Override
	public List<Question> getAllQuestions(int pagenum, int pagesize) {
		List<Question> questionList = new ArrayList<>();
		int startIndex = (pagenum-1)*pagesize;
		Connection cn = DBUtil.getConnection();
		String sql = "select * from question where question_status = ? order by question_id desc limit ?,?";
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			ps.setString(1, "δ���");
			ps.setInt(2, startIndex);
			ps.setInt(3, pagesize);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Question question = new Question();
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));	
				question.setAnswerId(rs.getInt(12));
				questionList.add(question);
			}
			DBUtil.close(rs, ps, cn);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return questionList;
	}
	@Override
	public List<Question> getAnswerList(int clientId) {
		List<Question> answers = new ArrayList<>();
		Connection cn = DBUtil.getConnection();
		String sql = "select * from question where answer_id = " + clientId;
		try {
			PreparedStatement ps = cn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Question question = new Question();
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));	
				question.setAnswerId(rs.getInt(12));
				answers.add(question);
				System.out.println(question.toString());
			}
			DBUtil.close(rs, ps, cn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return answers;
	}
	@Override
	public List<Question> getFilterData(String sql) {
		List<Question> questionList = new ArrayList<>();
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps =null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				Question question = new Question();
				question.setQuestionId(rs.getInt(1));
				question.setQuestionTitle(rs.getString(2));
				question.setQuestionContent(rs.getString(3));
				question.setQuestionPhoto(rs.getString(4));
				question.setPublisherId(rs.getInt(5));
				question.setPublisherOnlineTime(rs.getString(6));
				question.setQuestionLevel(rs.getString(7));
				question.setQuestionDirection(rs.getString(8));
				question.setQuestionMoney(rs.getInt(9));
				question.setQuestionStatus(rs.getString(10));
				question.setPublishTime(rs.getString(11));	
				question.setAnswerId(rs.getInt(12));
				questionList.add(question);
			}
			DBUtil.close(rs, ps, conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return questionList;
	}

}
