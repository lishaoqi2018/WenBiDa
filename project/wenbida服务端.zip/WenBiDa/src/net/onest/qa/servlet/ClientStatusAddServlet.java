package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.service.StatusService;
import net.onest.qa.service.impl.StatusServiceImpl;

/**
 * Servlet implementation class ClientStatusAddServlet
 */
@WebServlet("/ClientStatusAddServlet")
public class ClientStatusAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClientStatusAddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		byte[] buffer= new byte[1024];
		int len = in.read(buffer);
		String str = new String(buffer,0,len,"UTF-8");
		int clientId = new Gson().fromJson(str, Integer.class);
		StatusService ss = StatusServiceImpl.getInstance();
		//�ж�״̬���Ƿ��Ѿ��и��û�
		Boolean isExist = ss.isHaveStatus(clientId);
		if(isExist==false) {
			Boolean result = ss.addClient(clientId);
			if(result==true) {
				response.getWriter().append("���ӳɹ�");
			}else {
				response.getWriter().append("����ʧ��");
			}	
		}else {
			//ÿ�ε�½����״̬Ϊoff
			Boolean result = ss.updateClientStatus(clientId, "off");
			if(result==true) {
				response.getWriter().append("���óɹ�");
			}else {
				response.getWriter().append("����ʧ��");
			}	
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
