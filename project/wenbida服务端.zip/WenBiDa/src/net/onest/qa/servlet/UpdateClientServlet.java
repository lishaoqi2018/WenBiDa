package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.entity.Client;
import net.onest.qa.service.ClientService;
import net.onest.qa.service.impl.ClientServiceImpl;

/**
 * �����û���Ϣ
 */
@WebServlet("/UpdateClientServlet")
public class UpdateClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateClientServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		int len = -1;
		byte[] buffer = new byte[1024];
		StringBuffer sb = new StringBuffer();
		while((len = in.read(buffer)) != -1) {
			sb.append(new String(buffer,0,len,"utf-8"));
		}
		Client client = new Gson().fromJson(sb.toString(), Client.class);
		System.out.println(client.toString());
		ClientService cs = ClientServiceImpl.getInstance();
		Boolean b = cs.isUpdateInfo(client);
		if(b) {
			response.getWriter().append("�޸ĳɹ�");
		}else {
			response.getWriter().append("�޸�ʧ��");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
