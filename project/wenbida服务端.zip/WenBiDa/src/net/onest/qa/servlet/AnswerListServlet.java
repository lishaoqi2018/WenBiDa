package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.entity.Question;
import net.onest.qa.service.QuestionService;
import net.onest.qa.service.impl.QuestionServiceImpl;

/**
 * ��ûش��¼
 */
@WebServlet("/AnswerListServlet")
public class AnswerListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AnswerListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��ȡ�û�id
		InputStream is = request.getInputStream();
		byte[] b = new byte[256];
		int len = is.read(b);
		int clientId = Integer.parseInt(new String(b, 0, len, "utf-8"));
		System.out.println(""+clientId);
		QuestionService qs = QuestionServiceImpl.getInstance();
		List<Question> answers = qs.getAnswerList(clientId);
		Gson gson = new Gson();
		String jsonAnswers = gson.toJson(answers);
		System.out.println("�����б�"+jsonAnswers);
		response.getWriter().append(jsonAnswers);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
