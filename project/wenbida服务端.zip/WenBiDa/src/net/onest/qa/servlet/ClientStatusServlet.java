package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;
import net.onest.qa.entity.Status;
import net.onest.qa.service.StatusService;
import net.onest.qa.service.impl.StatusServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.google.gson.Gson;

/**
 * Servlet implementation class ClientStatusServlet
 */
@WebServlet("/ClientStatusServlet")
public class ClientStatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClientStatusServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		byte[] buffer = new byte[1024];
		int len = in.read(buffer);
		String str = new String(buffer,0,len,"UTF-8");
		System.out.println(str);
		Status status = new Gson().fromJson(str, Status.class);
		int clientId = status.getClientId();
		String st = status.getStatus(); 
		StatusService ss = StatusServiceImpl.getInstance();
		Boolean result = ss.updateClientStatus(clientId, st);
		if(result==true) {
			response.getWriter().append("�޸ĳɹ�");
		}else {
			
			response.getWriter().append("�޸�ʧ��");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
