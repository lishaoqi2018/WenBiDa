package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.onest.qa.entity.Client;
import net.onest.qa.entity.Question;
import net.onest.qa.service.ClientService;
import net.onest.qa.service.QuestionService;
import net.onest.qa.service.SubscribeService;
import net.onest.qa.service.impl.ClientServiceImpl;
import net.onest.qa.service.impl.QuestionServiceImpl;
import net.onest.qa.service.impl.SubscribeServiceImpl;

/**
 * Servlet implementation class PaymentAndEvaluateServlet
 */
@WebServlet("/PaymentAndEvaluateServlet")
public class PaymentAndEvaluateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentAndEvaluateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ClientService cs = ClientServiceImpl.getInstance();
		QuestionService qs = QuestionServiceImpl.getInstance();
		SubscribeService ss = SubscribeServiceImpl.getInstance();
		InputStream in = request.getInputStream();
		int len = -1;
		byte[] buffer = new byte[1024];
		StringBuffer sb = new StringBuffer();
		while((len = in.read(buffer)) != -1) {
			sb.append(new String(buffer,0,len,"utf-8"));
		}
		int questionId = Integer.parseInt(sb.toString().split("-")[0]);
		int answerId = Integer.parseInt(sb.toString().split("-")[1]);
		String flag = sb.toString().split("-")[2];
		
		//1����������id��ȡ�������û�id��������
		//2��������������
		//3���ش����������
		//4���޸�����״̬Ϊ  �ѽ��  answer_id = �ش���id
		//5���ش��߻ش��� +1
		//6���жϺ������Ƿ� +1
		//7���޸�ԤԼ���е�����״̬
		
		Question question = qs.getQuestionDetail(questionId);
		int publisherId = question.getPublisherId();
		int questionMoney = question.getQuestionMoney();
		
		Client publisher = cs.findClientInfo(publisherId);
		Client answer = cs.findClientInfo(answerId);
		int publisherBalance = publisher.getClientBalance() - questionMoney;
		int answerBalance = answer.getClientBalance() + questionMoney;
		Boolean b1 = cs.isUpdateBalance(publisherId, publisherBalance);
		Boolean b2 = cs.isUpdateBalance(answerId, answerBalance);
		
		question.setQuestionStatus("�ѽ��");
		question.setAnswerId(answerId);
		Boolean b3 = qs.updateQuestion(question, questionId);
		
		Boolean b4 = cs.isUpdateAnswerNum(answerId);
		Boolean b5 = false;
		if(flag.equals("true")) {
			b5 = cs.isUpdateOpinionNum(answerId);
		}
		
		Boolean b6 = ss.updateStatus(questionId);
		response.getWriter().append("PaymentAndEvaluateServlet:���ݸ��ĳɹ�");
		
		System.out.println("b1:"+ b1 + " b2:" + b2 + " b3:" + b3 + " b4:" + b4 + " b5:" + b5 + " b6:" + b6);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
