package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.entity.Subscribe;
import net.onest.qa.service.SubscribeService;
import net.onest.qa.service.impl.SubscribeServiceImpl;

/**
 * Servlet implementation class AddSubscribeServlet
 */
@WebServlet("/AddSubscribeServlet")
public class AddSubscribeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddSubscribeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		int len = -1;
		byte[] buffer = new byte[1024];
		StringBuffer sb = new StringBuffer();
		while((len = in.read(buffer)) != -1) {
			sb.append(new String(buffer,0,len,"utf-8"));
		}
		
		Subscribe sub = new Gson().fromJson(sb.toString(), Subscribe.class);
		
		SubscribeService ss = SubscribeServiceImpl.getInstance();
		Boolean b = ss.addSubscribe(sub.getSubscribedId(), sub.getQuestionId(),sub.getPublisherId());
		if(b) {
			response.getWriter().append("ԤԼ�ɹ�");
		}else {
			response.getWriter().append("ԤԼʧ��");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
