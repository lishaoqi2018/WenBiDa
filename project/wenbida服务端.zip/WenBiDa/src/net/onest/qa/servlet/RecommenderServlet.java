package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import net.onest.qa.entity.Client;
import net.onest.qa.service.ClientService;
import net.onest.qa.service.StatusService;
import net.onest.qa.service.impl.ClientServiceImpl;
import net.onest.qa.service.impl.StatusServiceImpl;

/**
 * Servlet implementation class RecommenderServlet
 */
@WebServlet("/RecommenderServlet")
public class RecommenderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecommenderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		byte[] buffer= new byte[1024];
		int len = in.read(buffer);
		System.out.println(new String(buffer,0,len,"UTF-8"));
		ClientService cs = ClientServiceImpl.getInstance();
		StatusService ss = StatusServiceImpl.getInstance();
		Gson gson = new Gson();
		
		List<Client> clients = new ArrayList<>();
		List<Client> selectClients = new ArrayList<>();
		List<Client> recommenderList = new ArrayList<>();
		
		String str = new String(buffer,0,len,"UTF-8");
	
		String[] data = str.split(",");
		if(data[0].equals("null")) {
			clients = cs.findAllClient("");
		}else {
			clients = cs.findAllClient(data[0]);
		}
		if(data[1].equals("on")) {
			selectClients = ss.findonLineClient(clients);
			clients = selectClients;
		}else if(data[1].equals("off")) {
			clients.removeAll(ss.findonLineClient(clients));
		}
		if(data[2].equals("����ش���")) {
			recommenderList = cs.findExcellentClient(clients);
			clients = recommenderList;
		}else if(data[2].equals("��ͨ�ش���")){
			clients.removeAll(cs.findExcellentClient(clients));
		}
		String backStr = gson.toJson(clients);
		System.out.println(backStr);
		response.getWriter().append(backStr);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
