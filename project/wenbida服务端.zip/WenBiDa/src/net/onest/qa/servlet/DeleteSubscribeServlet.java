package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.onest.qa.service.SubscribeService;
import net.onest.qa.service.impl.SubscribeServiceImpl;

/**
 * Servlet implementation class DeleteSubscribeServlet
 */
@WebServlet("/DeleteSubscribeServlet")
public class DeleteSubscribeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteSubscribeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��ȡ�û�id
		InputStream is = request.getInputStream();
		byte[] b = new byte[256];
		int len = is.read(b);
		int qId = Integer.parseInt(new String(b,0,len));
		
		System.out.println("Ҫȡ��ԤԼ������id:"+qId);
		SubscribeService ss = SubscribeServiceImpl.getInstance();
		boolean i = ss.deleteSubscribe(qId);
		if(i) {
			response.getWriter().append("ȡ��ԤԼ�ɹ�");
			System.out.println("ȡ��ԤԼ�ɹ�");
		}else {
			response.getWriter().append("ȡ��ԤԼʧ��");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
