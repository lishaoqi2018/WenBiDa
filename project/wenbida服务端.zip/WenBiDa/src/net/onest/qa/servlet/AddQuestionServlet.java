package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.dao.QuestionDao;
import net.onest.qa.dao.impl.QuestionDaoImpl;
import net.onest.qa.entity.Question;
import net.onest.qa.service.ClientService;
import net.onest.qa.service.QuestionService;
import net.onest.qa.service.impl.ClientServiceImpl;
import net.onest.qa.service.impl.QuestionServiceImpl;

/**
 * ��������
 */
@WebServlet("/AddQuestionServlet")
public class AddQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddQuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		QuestionService qs = QuestionServiceImpl.getInstance();
		ClientService cs = ClientServiceImpl.getInstance();
		int len = -1;
		byte[] buffer = new byte[1024];
		StringBuffer sb = new StringBuffer();
		while( (len = in.read(buffer)) != -1) {
			sb.append(new String(buffer,0,len,"utf-8"));
		}
		
		Question q = new Gson().fromJson(sb.toString(), Question.class);
		
		int publisherId = q.getPublisherId();
		Boolean b = cs.isUpdateQuestionNum(publisherId);
		System.out.println(b);
		
		int id = qs.addQuestion(q);
		
		if(id != -1) {
			response.getWriter().append(id+"");
		}
		System.out.println("�����ɹ�");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
