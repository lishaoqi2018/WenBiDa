package net.onest.qa.servlet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * �ϴ��û�ͷ��
 */
@WebServlet("/UploadClientImgServlet")
public class UploadClientImgServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadClientImgServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		String imgName = System.currentTimeMillis() + ".jpg";
		FileOutputStream fos = new FileOutputStream(getServletContext().getRealPath("client photo/") + imgName);
		byte[] buffer = new byte[1024];
		int len = 0;
		while((len = in.read(buffer))!=-1){
			fos.write(buffer,0,len);
		}
		fos.flush();
		fos.close();
		in.close();
		
		response.getWriter().append(imgName);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
