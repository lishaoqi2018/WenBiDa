package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.entity.Question;
import net.onest.qa.service.QuestionService;
import net.onest.qa.service.impl.QuestionServiceImpl;

/**
 * Servlet implementation class QuestionRecordUnresolveDetailServlet
 */
@WebServlet("/QuestionRecordUnresolveDetailServlet")
public class QuestionRecordUnresolveDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuestionRecordUnresolveDetailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		byte[] buffer = new byte[1024];
		int len = in.read(buffer);
		String str = new String(buffer,0,len,"UTF-8");
		int id = new Gson().fromJson(str, Integer.class);
		QuestionService qs =QuestionServiceImpl.getInstance();
		Question question = qs.getQuestionDetail(id);
		String questionDetail = new Gson().toJson(question);
		response.getWriter().append(questionDetail);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
