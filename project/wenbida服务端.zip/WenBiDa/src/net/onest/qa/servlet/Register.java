package net.onest.qa.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.onest.qa.entity.Client;
import net.onest.qa.service.ClientService;
import net.onest.qa.service.impl.ClientServiceImpl;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Client client = new Client();
        String userPhone = request.getParameter("userphone");
		String userPassword = request.getParameter("password");
        client.setClientPhone(userPhone);
        client.setPassword(userPassword);
        ClientService cs = ClientServiceImpl.getInstance();
        if(cs.isExistUser(client)) {
        	response.getWriter().append("false");
        }else {
        	cs.isAddUser(client);
        	response.getWriter().append("true");
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
