package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.entity.Client;
import net.onest.qa.service.ClientService;
import net.onest.qa.service.impl.ClientServiceImpl;

/**
 * �Ƽ�������
 */
@WebServlet("/RecommenderDeatilServlet")
public class RecommenderDeatilServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecommenderDeatilServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��ȡid
		InputStream in = request.getInputStream();
		byte[] b = new byte[1024];
		int len = in.read(b);
		int rId = Integer.parseInt(new String(b,0,len));
		//���������Ƽ�������
		ClientService cs = ClientServiceImpl.getInstance();
		Client client = cs.findClientInfo(rId);
		Gson gson = new Gson();
		String str = gson.toJson(client);
		System.out.println(str);
		OutputStream out = response.getOutputStream();
		out.write(str.getBytes("utf-8"));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
