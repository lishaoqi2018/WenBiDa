package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.entity.Client;
import net.onest.qa.service.ClientService;
import net.onest.qa.service.impl.ClientServiceImpl;

/**
 * ��ȡ�û���Ϣ,�����û�id
 */
@WebServlet("/GetCilentValueServlet")
public class GetCilentValueServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetCilentValueServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = request.getInputStream();
		byte[] buffer = new byte[1024];
		int len = in.read(buffer);
		int clientId = Integer.parseInt(new String(buffer,0,len,"utf-8"));
		ClientService cs = ClientServiceImpl.getInstance();
		Client client = cs.findClientInfo(clientId);
		response.getWriter().append(new Gson().toJson(client));
		System.out.println("������Ϣ�ɹ�");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
