package net.onest.qa.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.entity.Question;
import net.onest.qa.service.QuestionService;
import net.onest.qa.service.impl.QuestionServiceImpl;

/**
 * Servlet implementation class getAllQuestions
 */
@WebServlet("/getAllQuestions")
public class getAllQuestions extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getAllQuestions() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String currentPage = request.getParameter("pageNum");
		String pageSize = request.getParameter("pageSize");	
		int pageNum = Integer.parseInt(currentPage);
		int size = Integer.parseInt(pageSize);
		List<Question> questionlist = new ArrayList<>();
		QuestionService qs = QuestionServiceImpl.getInstance();
		questionlist = qs.getAllQuestions(pageNum, size);
		response.getWriter().append(new Gson().toJson(questionlist));
		System.out.println("�ɹ���������");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
