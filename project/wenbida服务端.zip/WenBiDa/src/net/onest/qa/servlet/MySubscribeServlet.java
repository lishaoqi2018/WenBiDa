package net.onest.qa.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.onest.qa.entity.Question;
import net.onest.qa.entity.Subscribe;
import net.onest.qa.service.QuestionService;
import net.onest.qa.service.SubscribeService;
import net.onest.qa.service.impl.QuestionServiceImpl;
import net.onest.qa.service.impl.SubscribeServiceImpl;

/**
 * �ҵ�ԤԼ
 */
@WebServlet("/MySubscribeServlet")
public class MySubscribeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MySubscribeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��ȡid
		InputStream in = request.getInputStream();
		byte[] b = new byte[1024];
		int len = in.read(b);
		int sId = Integer.parseInt(new String(b,0,len));
		//�����ҵ��б�
		SubscribeService ss = SubscribeServiceImpl.getInstance();
		List<Subscribe> subscribes = ss.getMySubscribe(sId);
		Gson gson = new Gson();
		List<Question> questions = new ArrayList<Question>();
		for(Subscribe subscribe : subscribes) {
			//��ȡ�����б�
			int qId = subscribe.getQuestionId();
			QuestionService qs = QuestionServiceImpl.getInstance();
			Question question = qs.getQuestionDetail(qId);
			questions.add(question);
		}
		String str = gson.toJson(questions);
		OutputStream out = response.getOutputStream();
		out.write(str.getBytes("utf-8"));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
